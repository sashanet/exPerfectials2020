package model;

/**
 * @author Oleksandr Buryk
 */
public class Library {

    public int id;
    public int booksAmount;
    public int signUpProcess;
    public int booksPerDay;
    public Integer[] booksIds;
}
