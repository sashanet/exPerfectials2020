package model;

/**
 * @author Oleksandr Buryk
 */
public class Book {
}
